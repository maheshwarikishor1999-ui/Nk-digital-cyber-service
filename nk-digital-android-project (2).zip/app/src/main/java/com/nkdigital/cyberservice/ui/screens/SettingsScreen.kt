package com.nkdigital.cyberservice.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nkdigital.cyberservice.ui.components.LogoHeader
import com.nkdigital.cyberservice.ui.components.SignaturePad

@Composable
fun SettingsScreen(
    currentSignature: String?,
    onSaveSignature: (String?) -> Unit
) {
    var isEditingSignature by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Center Profile & Settings",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        LogoHeader()

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Verified Business Information", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Name: NK DIGITAL CYBER SERVICE", fontSize = 12.sp)
                Text("Address: Behind Lions Club of Madhapar, Bhuj - 370020, Gujarat, India.", fontSize = 12.sp)
                Text("Mobile: 9664542803", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Business Owner Signature", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "Appears on generated PDF receipts above 'Authorized Signature'. Draw your finger on the screen below.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                if (isEditingSignature) {
                    SignaturePad(
                        onSaveSignature = {
                            onSaveSignature(it)
                            isEditingSignature = false
                        },
                        onClear = { onSaveSignature(null) }
                    )
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { isEditingSignature = true }) {
                            Text(if (currentSignature != null) "Redraw Signature" else "Draw Signature")
                        }
                        if (currentSignature != null) {
                            OutlinedButton(onClick = { onSaveSignature(null) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
            }
        }
    }
}
