package com.nkdigital.cyberservice.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Blue900,
    secondary = Cyan600,
    tertiary = Orange600,
    background = Blue950,
    surface = Slate800
)

private val LightColorScheme = lightColorScheme(
    primary = Blue900,
    secondary = Cyan600,
    tertiary = Orange600,
    background = Slate100,
    surface = White
)

@Composable
fun NKDigitalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
