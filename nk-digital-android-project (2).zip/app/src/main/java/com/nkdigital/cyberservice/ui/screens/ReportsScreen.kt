package com.nkdigital.cyberservice.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nkdigital.cyberservice.data.model.BillEntity
import com.nkdigital.cyberservice.data.model.ExpenseEntity
import kotlinx.coroutines.flow.Flow
import java.util.Locale

@Composable
fun ReportsScreen(
    billsFlow: Flow<List<BillEntity>>,
    expensesFlow: Flow<List<ExpenseEntity>>
) {
    val bills by billsFlow.collectAsState(initial = emptyList())
    val expenses by expensesFlow.collectAsState(initial = emptyList())

    val totalRevenue = bills.sumOf { it.amountPaid }
    val totalExpenses = expenses.sumOf { it.amount }
    val netProfit = totalRevenue - totalExpenses
    val totalOutstanding = bills.sumOf { it.balanceAmount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Financial Reports & Analytics",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Business Summary", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Income Received:")
                    Text("₹${String.format(Locale.US, "%.2f", totalRevenue)}", fontWeight = FontWeight.Bold)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Expenses:")
                    Text("₹${String.format(Locale.US, "%.2f", totalExpenses)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                }

                Divider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Net Cashflow:", fontWeight = FontWeight.Black)
                    Text("₹${String.format(Locale.US, "%.2f", netProfit)}", fontWeight = FontWeight.Black, color = if (netProfit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Customer Outstanding Due:")
                    Text("₹${String.format(Locale.US, "%.2f", totalOutstanding)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
