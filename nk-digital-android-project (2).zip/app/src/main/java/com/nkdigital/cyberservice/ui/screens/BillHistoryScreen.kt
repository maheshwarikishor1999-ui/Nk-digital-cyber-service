package com.nkdigital.cyberservice.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.nkdigital.cyberservice.data.model.BillEntity
import com.nkdigital.cyberservice.util.PdfReceiptGenerator
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun BillHistoryScreen(
    billsFlow: Flow<List<BillEntity>>,
    onDeleteBill: (BillEntity) -> Unit
) {
    val context = LocalContext.current
    val bills by billsFlow.collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }

    val filtered = bills.filter {
        it.billNumber.contains(searchQuery, ignoreCase = true) ||
        it.customerName.contains(searchQuery, ignoreCase = true) ||
        it.customerMobile.contains(searchQuery)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Bill History & Invoices",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search by Bill No, Name, or Mobile") },
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.id }) { bill ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(bill.billNumber, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            Text(
                                bill.paymentStatus,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (bill.balanceAmount <= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }

                        Text("Customer: ${bill.customerName} (${bill.customerMobile})", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(bill.createdAt))
                        Text(dateStr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total: ₹${String.format(Locale.US, "%.2f", bill.finalAmount)}", fontWeight = FontWeight.Bold)
                            Text("Paid: ₹${String.format(Locale.US, "%.2f", bill.amountPaid)}")
                            if (bill.balanceAmount > 0) {
                                Text("Due: ₹${String.format(Locale.US, "%.2f", bill.balanceAmount)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    val pdfFile = PdfReceiptGenerator.generatePdf(context, bill)
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.provider",
                                        pdfFile
                                    )
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Open Bill PDF"))
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Download / View PDF", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
