package com.nkdigital.cyberservice

import android.app.Application
import com.nkdigital.cyberservice.data.local.AppDatabase
import com.nkdigital.cyberservice.data.repository.BillingRepository

class NKDigitalApp : Application() {
    lateinit var repository: BillingRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getDatabase(this)
        repository = BillingRepository(database)
    }
}
