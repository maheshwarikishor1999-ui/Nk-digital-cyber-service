package com.nkdigital.cyberservice.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bills")
data class BillEntity(
    @PrimaryKey val id: String,
    val billNumber: String,
    val createdAt: Long,
    val customerId: String,
    val customerName: String,
    val customerMobile: String,
    val customerAddress: String? = null,
    val itemsJson: String,
    val subtotal: Double,
    val discount: Double = 0.0,
    val finalAmount: Double,
    val amountPaid: Double,
    val balanceAmount: Double,
    val paymentMethod: String,
    val paymentStatus: String,
    val paymentReference: String? = null,
    val notes: String? = null,
    val signatureBase64: String? = null
)
