package com.nkdigital.cyberservice.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.ByteArrayOutputStream

@Composable
fun SignaturePad(
    modifier: Modifier = Modifier,
    onSaveSignature: (base64: String) -> Unit,
    onClear: () -> Unit = {}
) {
    val points = remember { mutableStateListOf<Offset>() }

    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(Color.White, RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        points.add(change.position)
                    }
                }
        ) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                for (i in 0 until points.size - 1) {
                    val p1 = points[i]
                    val p2 = points[i + 1]
                    if ((p1 - p2).getDistance() < 50f) {
                        drawLine(
                            color = Color(0xFF0F2B5C),
                            start = p1,
                            end = p2,
                            strokeWidth = 4f
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(
                onClick = {
                    points.clear()
                    onClear()
                }
            ) {
                Text("Clear", fontSize = 12.sp)
            }

            Button(
                onClick = {
                    if (points.isNotEmpty()) {
                        val bitmap = Bitmap.createBitmap(400, 180, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bitmap)
                        val paint = Paint().apply {
                            color = android.graphics.Color.parseColor("#0F2B5C")
                            strokeWidth = 4f
                            style = Paint.Style.STROKE
                            isAntiAlias = true
                        }
                        for (i in 0 until points.size - 1) {
                            val p1 = points[i]
                            val p2 = points[i + 1]
                            if ((p1 - p2).getDistance() < 50f) {
                                canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint)
                            }
                        }
                        val stream = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                        val base64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                        onSaveSignature(base64)
                    }
                }
            ) {
                Text("Save Signature", fontSize = 12.sp)
            }
        }
    }
}
