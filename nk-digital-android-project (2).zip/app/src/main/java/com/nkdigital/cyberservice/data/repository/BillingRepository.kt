package com.nkdigital.cyberservice.data.repository

import com.nkdigital.cyberservice.data.local.AppDatabase
import com.nkdigital.cyberservice.data.model.BillEntity
import com.nkdigital.cyberservice.data.model.CustomerEntity
import com.nkdigital.cyberservice.data.model.ExpenseEntity
import kotlinx.coroutines.flow.Flow

class BillingRepository(private val db: AppDatabase) {

    fun getAllBills(): Flow<List<BillEntity>> = db.billDao().getAllBills()
    fun getAllCustomers(): Flow<List<CustomerEntity>> = db.customerDao().getAllCustomers()
    fun getAllExpenses(): Flow<List<ExpenseEntity>> = db.expenseDao().getAllExpenses()

    suspend fun saveBill(bill: BillEntity) {
        db.billDao().insertBill(bill)

        val existingCustomer = db.customerDao().getCustomerById(bill.customerId)
        if (existingCustomer != null) {
            val updated = existingCustomer.copy(
                totalBills = existingCustomer.totalBills + 1,
                totalSpent = existingCustomer.totalSpent + bill.finalAmount,
                totalBalance = existingCustomer.totalBalance + bill.balanceAmount,
                lastVisit = bill.createdAt
            )
            db.customerDao().updateCustomer(updated)
        } else {
            val newCustomer = CustomerEntity(
                id = bill.customerId,
                name = bill.customerName,
                mobile = bill.customerMobile,
                address = bill.customerAddress,
                totalBills = 1,
                totalSpent = bill.finalAmount,
                totalBalance = bill.balanceAmount,
                lastVisit = bill.createdAt
            )
            db.customerDao().insertCustomer(newCustomer)
        }
    }

    suspend fun deleteBill(bill: BillEntity) = db.billDao().deleteBill(bill)
    suspend fun saveExpense(expense: ExpenseEntity) = db.expenseDao().insertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = db.expenseDao().deleteExpense(expense)
    suspend fun saveCustomer(customer: CustomerEntity) = db.customerDao().insertCustomer(customer)
}
