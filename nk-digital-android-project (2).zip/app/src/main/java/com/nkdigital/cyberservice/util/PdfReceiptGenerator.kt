package com.nkdigital.cyberservice.util

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.util.Base64
import com.nkdigital.cyberservice.R
import com.nkdigital.cyberservice.data.model.BillEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfReceiptGenerator {

    fun generatePdf(context: Context, bill: BillEntity): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 (595 x 842 pt)
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint().apply { isAntiAlias = true }

        // 1. Draw Business Logo
        try {
            val logoBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.logo)
            if (logoBitmap != null) {
                val scaledLogo = Bitmap.createScaledBitmap(logoBitmap, 64, 64, true)
                canvas.drawBitmap(scaledLogo, (595f - 64f) / 2f, 25f, paint)
            }
        } catch (_: Exception) {}

        // 2. Business Header
        paint.color = Color.parseColor("#0F172A")
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("NK DIGITAL CYBER SERVICE", 595f / 2f, 110f, paint)

        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Behind Lions Club of Madhapar, Bhuj - 370020, Gujarat, India.", 595f / 2f, 126f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Mobile: 9664542803", 595f / 2f, 140f, paint)

        // Receipt Banner
        paint.textSize = 12f
        canvas.drawText("PAYMENT RECEIPT / INVOICE", 595f / 2f, 165f, paint)

        // Horizontal Line
        paint.strokeWidth = 1f
        paint.color = Color.LTGRAY
        canvas.drawLine(40f, 175f, 555f, 175f, paint)

        // Customer & Bill Metadata
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.BLACK
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Customer: ${bill.customerName}", 40f, 195f, paint)
        canvas.drawText("Mobile: ${bill.customerMobile}", 40f, 212f, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Bill No: ${bill.billNumber}", 555f, 195f, paint)
        val dateStr = SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.getDefault()).format(Date(bill.createdAt))
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Date: $dateStr", 555f, 212f, paint)

        // Financials Box
        canvas.drawLine(40f, 230f, 555f, 230f, paint)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("Subtotal:", 40f, 255f, paint)
        canvas.drawText("Discount:", 40f, 275f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Total Payable:", 40f, 295f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Amount Paid (${bill.paymentMethod}):", 40f, 315f, paint)
        canvas.drawText("Balance Due:", 40f, 335f, paint)

        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("₹${String.format(Locale.US, "%.2f", bill.subtotal)}", 555f, 255f, paint)
        canvas.drawText("- ₹${String.format(Locale.US, "%.2f", bill.discount)}", 555f, 275f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("₹${String.format(Locale.US, "%.2f", bill.finalAmount)}", 555f, 295f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("₹${String.format(Locale.US, "%.2f", bill.amountPaid)}", 555f, 315f, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("₹${String.format(Locale.US, "%.2f", bill.balanceAmount)}", 555f, 335f, paint)

        // Signature Section
        canvas.drawLine(40f, 400f, 555f, 400f, paint)
        if (!bill.signatureBase64.isNullOrEmpty()) {
            try {
                val bytes = Base64.decode(bill.signatureBase64, Base64.DEFAULT)
                val signBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (signBitmap != null) {
                    val scaledSign = Bitmap.createScaledBitmap(signBitmap, 120, 50, true)
                    canvas.drawBitmap(scaledSign, 555f - 120f, 415f, paint)
                }
            } catch (_: Exception) {}
        }
        canvas.drawLine(415f, 470f, 555f, 470f, paint)
        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Authorized Signature", 555f, 485f, paint)
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("NK DIGITAL CYBER SERVICE", 555f, 498f, paint)

        // Footer Note
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Thank you for choosing NK DIGITAL CYBER SERVICE!", 595f / 2f, 540f, paint)

        pdfDocument.finishPage(page)

        val file = File(context.cacheDir, "${bill.billNumber}.pdf")
        val outputStream = FileOutputStream(file)
        pdfDocument.writeTo(outputStream)
        outputStream.close()
        pdfDocument.close()
        return file
    }
}
