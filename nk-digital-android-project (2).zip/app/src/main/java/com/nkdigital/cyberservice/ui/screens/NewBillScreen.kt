package com.nkdigital.cyberservice.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nkdigital.cyberservice.data.model.BillEntity
import com.nkdigital.cyberservice.ui.components.SignaturePad
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun NewBillScreen(
    onSaveBill: suspend (BillEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var customerName by remember { mutableStateOf("") }
    var customerMobile by remember { mutableStateOf("") }
    var serviceName by remember { mutableStateOf("Online Form Application") }
    var rateStr by remember { mutableStateOf("150") }
    var quantityStr by remember { mutableStateOf("1") }
    var discountStr by remember { mutableStateOf("0") }
    var amountPaidStr by remember { mutableStateOf("150") }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var signatureBase64 by remember { mutableStateOf<String?>(null) }
    var showSignaturePad by remember { mutableStateOf(false) }

    val rate = rateStr.toDoubleOrNull() ?: 0.0
    val quantity = quantityStr.toIntOrNull() ?: 1
    val discount = discountStr.toDoubleOrNull() ?: 0.0
    val subtotal = rate * quantity
    val finalAmount = (subtotal - discount).coerceAtLeast(0.0)
    val amountPaid = (amountPaidStr.toDoubleOrNull() ?: finalAmount).coerceAtLeast(0.0)
    val balance = (finalAmount - amountPaid).coerceAtLeast(0.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Create New Bill",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "NK DIGITAL CYBER SERVICE • Bhuj",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        item {
            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name *") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = customerMobile,
                onValueChange = { customerMobile = it },
                label = { Text("Customer Mobile *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = serviceName,
                onValueChange = { serviceName = it },
                label = { Text("Service Description") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = rateStr,
                    onValueChange = { rateStr = it },
                    label = { Text("Rate (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = { quantityStr = it },
                    label = { Text("Qty") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = discountStr,
                    onValueChange = { discountStr = it },
                    label = { Text("Disc (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Total Payable: ₹${String.format(Locale.US, "%.2f", finalAmount)}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Balance Due: ₹${String.format(Locale.US, "%.2f", balance)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amountPaidStr,
                    onValueChange = { amountPaidStr = it },
                    label = { Text("Amount Paid (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = paymentMethod,
                    onValueChange = { paymentMethod = it },
                    label = { Text("Method (Cash/UPI)") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            OutlinedButton(
                onClick = { showSignaturePad = !showSignaturePad },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (signatureBase64 != null) "✓ Signature Captured (Tap to Redraw)" else "Add Signature (Optional)")
            }
        }

        if (showSignaturePad) {
            item {
                SignaturePad(
                    onSaveSignature = {
                        signatureBase64 = it
                        showSignaturePad = false
                    },
                    onClear = { signatureBase64 = null }
                )
            }
        }

        item {
            Button(
                onClick = {
                    if (customerName.isNotBlank() && customerMobile.isNotBlank()) {
                        val billId = UUID.randomUUID().toString()
                        val billNum = "NK-${System.currentTimeMillis() % 100000}"
                        val status = when {
                            balance <= 0.0 -> "PAID"
                            amountPaid > 0.0 -> "PARTIALLY PAID"
                            else -> "UNPAID"
                        }
                        val bill = BillEntity(
                            id = billId,
                            billNumber = billNum,
                            createdAt = System.currentTimeMillis(),
                            customerId = customerMobile.trim(),
                            customerName = customerName.trim(),
                            customerMobile = customerMobile.trim(),
                            itemsJson = "[{\"name\":\"$serviceName\",\"rate\":$rate,\"qty\":$quantity}]",
                            subtotal = subtotal,
                            discount = discount,
                            finalAmount = finalAmount,
                            amountPaid = amountPaid,
                            balanceAmount = balance,
                            paymentMethod = paymentMethod.ifBlank { "Cash" },
                            paymentStatus = status,
                            signatureBase64 = signatureBase64
                        )
                        coroutineScope.launch {
                            onSaveBill(bill)
                            onNavigateBack()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Bill & Generate Invoice", fontWeight = FontWeight.Bold)
            }
        }
    }
}
