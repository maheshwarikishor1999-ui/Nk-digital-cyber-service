package com.nkdigital.cyberservice.ui.theme

import androidx.compose.ui.graphics.Color

val Blue900 = Color(0xFF1E3A8A)
val Blue950 = Color(0xFF0F172A)
val Cyan600 = Color(0xFF0284C7)
val Orange600 = Color(0xFFEA580C)
val Emerald600 = Color(0xFF059669)
val Rose600 = Color(0xFFE11D48)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate800 = Color(0xFF1E293B)
val White = Color(0xFFFFFFFF)
