package com.nkdigital.cyberservice.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.*
import com.nkdigital.cyberservice.data.repository.BillingRepository
import com.nkdigital.cyberservice.ui.screens.*

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object NewBill : Screen("new_bill", "New Bill", Icons.Default.AddCircle)
    object History : Screen("history", "History", Icons.Default.Receipt)
    object Customers : Screen("customers", "Customers", Icons.Default.People)
    object Expenses : Screen("expenses", "Expenses", Icons.Default.AccountBalanceWallet)
    object Reports : Screen("reports", "Reports", Icons.Default.BarChart)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun NKNavGraph(repository: BillingRepository) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var ownerSignature by remember { mutableStateOf<String?>(null) }

    val items = listOf(
        Screen.Dashboard,
        Screen.NewBill,
        Screen.History,
        Screen.Customers,
        Screen.Expenses,
        Screen.Reports,
        Screen.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Dashboard.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    billsFlow = repository.getAllBills(),
                    onNavigateNewBill = { navController.navigate(Screen.NewBill.route) },
                    onNavigateHistory = { navController.navigate(Screen.History.route) }
                )
            }
            composable(Screen.NewBill.route) {
                NewBillScreen(
                    onSaveBill = { bill ->
                        val billWithSign = if (bill.signatureBase64 == null && ownerSignature != null) {
                            bill.copy(signatureBase64 = ownerSignature)
                        } else {
                            bill
                        }
                        repository.saveBill(billWithSign)
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(Screen.History.route) {
                BillHistoryScreen(
                    billsFlow = repository.getAllBills(),
                    onDeleteBill = { bill ->
                        // Delete logic
                    }
                )
            }
            composable(Screen.Customers.route) {
                CustomerScreen(customersFlow = repository.getAllCustomers())
            }
            composable(Screen.Expenses.route) {
                ExpenseScreen(
                    expensesFlow = repository.getAllExpenses(),
                    onSaveExpense = { exp -> repository.saveExpense(exp) }
                )
            }
            composable(Screen.Reports.route) {
                ReportsScreen(
                    billsFlow = repository.getAllBills(),
                    expensesFlow = repository.getAllExpenses()
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    currentSignature = ownerSignature,
                    onSaveSignature = { ownerSignature = it }
                )
            }
        }
    }
}
