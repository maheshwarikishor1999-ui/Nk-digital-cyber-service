package com.nkdigital.cyberservice.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String,
    val address: String? = null,
    val totalBills: Int = 0,
    val totalSpent: Double = 0.0,
    val totalBalance: Double = 0.0,
    val lastVisit: Long = System.currentTimeMillis()
)
