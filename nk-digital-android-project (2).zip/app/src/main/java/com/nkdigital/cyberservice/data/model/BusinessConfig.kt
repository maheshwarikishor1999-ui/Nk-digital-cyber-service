package com.nkdigital.cyberservice.data.model

data class BusinessConfig(
    val name: String = "NK DIGITAL CYBER SERVICE",
    val address: String = "Behind Lions Club of Madhapar",
    val city: String = "Bhuj",
    val pincode: String = "370020",
    val state: String = "Gujarat",
    val mobile: String = "9664542803",
    val thankYouEn: String = "Thank you for choosing NK DIGITAL CYBER SERVICE!",
    val thankYouGu: String = "NK DIGITAL CYBER SERVICE પસંદ કરવા બદલ આપનો ખૂબ ખૂબ આભાર!",
    val signatureBase64: String? = null,
    val upiQrBase64: String? = null,
    val upiId: String? = "9664542803@upi"
)
