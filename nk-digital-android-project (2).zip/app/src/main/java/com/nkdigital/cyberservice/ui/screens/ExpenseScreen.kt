package com.nkdigital.cyberservice.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nkdigital.cyberservice.data.model.ExpenseEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ExpenseScreen(
    expensesFlow: Flow<List<ExpenseEntity>>,
    onSaveExpense: suspend (ExpenseEntity) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val expenses by expensesFlow.collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Paper & Stationery") }

    val totalExpenses = expenses.sumOf { it.amount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Expense Tracker",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Total Recorded Expenses", fontSize = 11.sp)
                Text("₹${String.format(Locale.US, "%.2f", totalExpenses)}", fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Expense Title (e.g. A4 Paper Rim)") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = amountStr,
                onValueChange = { amountStr = it },
                label = { Text("Amount (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("Category") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = {
                val amt = amountStr.toDoubleOrNull()
                if (title.isNotBlank() && amt != null && amt > 0) {
                    val exp = ExpenseEntity(
                        id = UUID.randomUUID().toString(),
                        date = System.currentTimeMillis(),
                        title = title.trim(),
                        category = category.trim(),
                        amount = amt,
                        paymentMethod = "Cash"
                    )
                    coroutineScope.launch {
                        onSaveExpense(exp)
                        title = ""
                        amountStr = ""
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Add Expense")
        }

        Divider()

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(expenses, key = { it.id }) { item ->
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(item.title, fontWeight = FontWeight.Bold)
                            val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.date))
                            Text("${item.category} • $dateStr", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        }
                        Text("₹${String.format(Locale.US, "%.2f", item.amount)}", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
