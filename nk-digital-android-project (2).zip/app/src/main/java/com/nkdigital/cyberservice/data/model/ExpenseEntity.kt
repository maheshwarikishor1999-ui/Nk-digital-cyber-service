package com.nkdigital.cyberservice.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val date: Long,
    val title: String,
    val category: String,
    val amount: Double,
    val paymentMethod: String,
    val notes: String? = null
)
