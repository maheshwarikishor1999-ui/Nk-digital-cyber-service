package com.nkdigital.cyberservice.data.local

import androidx.room.*
import com.nkdigital.cyberservice.data.model.BillEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    fun getAllBills(): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getBillsByCustomer(customerId: String): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: String): BillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: BillEntity)

    @Update
    suspend fun updateBill(bill: BillEntity)

    @Delete
    suspend fun deleteBill(bill: BillEntity)

    @Query("SELECT SUM(amountPaid) FROM bills WHERE createdAt >= :startTime")
    suspend fun getCollectionsSince(startTime: Long): Double?

    @Query("SELECT SUM(balanceAmount) FROM bills")
    suspend fun getTotalOutstanding(): Double?
}
